import cv2
import numpy as np
import PIL.Image as im
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.path as mplPath

# Read images : src image will be cloned into dst
matplotlib.rcParams['font.sans-serif']=['SimHei']
flag = 1
obj= np.array(im.open(r"rdfzai.png"))[:,:,:3] #复制粘贴图片
dst = np.array(im.open(r"sea.jpg"))[:,:,:3] #目标图片
points = []
cords = [0,0]
fig  = plt.figure()
ax = fig.add_subplot(111)

def Is_Press(event):
    global n,flag,cords
    if flag == 1:
        points.append([event.xdata,event.ydata])
    elif flag == 2:
        cords = tuple([event.xdata,event.ydata])
def Is_Key_Press(event):
    global flag
    if (flag == 1 or flag == 2)and event.key == ' ':
        flag = 0
def plot_line(points):
    if len(points)>0:
        plot = np.array(points)
        ax.clear()
        plt.imshow(obj)
        ax.plot(plot[:,0],plot[:,1],c = 'r')
        ax.scatter(plot[:,0],plot[:,1],c = 'r')
        ax.plot([plot[0][0],plot[-1][0]],[plot[0][1],plot[-1][1]],c = 'r')
    plt.pause(0.1)
fig.canvas.mpl_connect('button_press_event', Is_Press)
fig.canvas.mpl_connect('key_press_event', Is_Key_Press)
plt.imshow(obj)
#print("选出你想要移动到目标图片的区域，红线表示选中的范围，按空格结束")

while flag:
    ax.set_title("用左键画任意多边形选出你想要复制到目标图片的区域，红线表示选中的范围，按空格结束",fontsize = 9)
    plot_line(points)
    
plot_line(points)
poly_path = mplPath.Path(points)
mask = np.zeros(obj.shape, obj.dtype)
# Create an all white mask
for i in range(obj.shape[0]):
    for j in range(obj.shape[1]):
        if poly_path.contains_points([[i,j]]):
            mask [j][i] = 255
ax.set_title("Mask")
plt.imshow(mask)
plt.pause(1)



# The location of the center of the src in the dst

width, height, channels = dst.shape
flag = 2
#print("用鼠标左键选出你想要复制到的位置，红点表示目前选中的位置，按空格结束")
while flag:
    
    ax.clear()
    ax.set_title("用鼠标左键点击选出你想要复制到的位置，红点表示目前选中的位置，按空格结束")
    plt.imshow(dst)
    ax.scatter(cords[0],cords[1],c = 'r')
    plt.pause(0.1)
center =  (int(cords[0]),int(cords[1]))

# Seamlessly clone src into dst and put the results in output
normal_clone = cv2.seamlessClone(obj, dst, mask, center, cv2.NORMAL_CLONE)
mixed_clone = cv2.seamlessClone(obj, dst, mask, center, cv2.MIXED_CLONE)

# Write resultsa
ax.clear()
ax.imshow(normal_clone)
plt.show()
ax.imshow(mixed_clone)
plt.show()
plt.imsave('normal_clone.png', normal_clone)
plt.imsave('mixed_clone.png', mixed_clone)
