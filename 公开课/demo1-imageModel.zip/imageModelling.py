# -*- coding: utf-8 -*-
"""
Created on Mon May  6 20:53:35 2019

@author: zhang_000
"""
import cv2 as cv
import numpy as np
import matplotlib.pyplot as plt


# 通道分离，输出三个单通道图片
src = cv.imread("image.jpg") #读取图像
b, g, r = cv.split(src) # 将彩色图像分割成3个通道
#cv.imshow("blue", b)
#cv.imshow("green", g)
#cv.imshow("red", r)

###############通道分离结束#########################


#使用matplotlib绘图
fig = plt.figure() 

#绘制2x2两行两列共四个图，编号从1开始
ax = fig.add_subplot(221)
src = cv.cvtColor(src,cv.COLOR_BGR2RGB)

ax.imshow(src)
ax.set_xlabel('former')#添加标签
plt.xticks([])#关闭刻度
plt.yticks([])#关闭刻度

ax = fig.add_subplot(222)
ax.imshow(r,cmap=plt.cm.gray)#使用自定义的colormap(灰度图)
ax.set_xlabel('R channel')#添加标签
plt.xticks([])#关闭刻度
plt.yticks([])#关闭刻度

ax = fig.add_subplot(223)
ax.imshow(g,cmap=plt.cm.gray)#使用自定义的colormap(灰度图)
ax.set_xlabel('G channel')#添加标签
plt.xticks([])#关闭刻度
plt.yticks([])#关闭刻度


ax = fig.add_subplot(224)
ax.imshow(b,cmap=plt.cm.gray)#使用自定义的colormap(灰度图)
ax.set_xlabel('B channel')#添加标签
plt.xticks([])#关闭刻度
plt.yticks([])#关闭刻度
plt.show()#图片的显示